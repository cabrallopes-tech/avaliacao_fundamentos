document.addEventListener('DOMContentLoaded', () => {

  const form = document.getElementById('formFilme');
  const tituloInput = document.getElementById('titulo');
  const sinopseInput = document.getElementById('sinopse');
  const anoInput = document.getElementById('ano');
  const mensagem = document.getElementById('mensagem');
  const listaFilmes = document.getElementById('listaFilmes');

  const filmes = [];

  // Evento input
  tituloInput.addEventListener('input', () => {
    mensagem.textContent = `Título digitado: ${tituloInput.value}`;
    mensagem.className = 'mt-4 text-sm text-blue-600';
  });

  // Evento submit
  form.addEventListener('submit', (event) => {

    // Impede o recarregamento da página
    event.preventDefault();

    const titulo = tituloInput.value.trim().toUpperCase();
    const sinopse = sinopseInput.value.trim();
    const ano = Number(anoInput.value);

    // Validação
    if (titulo === '' || sinopse === '' || ano === '') {
      mensagem.textContent = 'Preencha todos os campos!';
      mensagem.className = 'mt-4 text-sm text-red-600';
      return;
    }

    // Exemplo de uso do filter()
    const filmesExistentes = filmes.filter((filme) => {
      return filme.titulo === titulo;
    });

    if (filmesExistentes.length > 0) {
      mensagem.textContent = 'Este filme já está cadastrado!';
      mensagem.className = 'mt-4 text-sm text-red-600';
      return;
    }

    // Adiciona o filme ao array
    filmes.push({
      titulo: titulo,
      sinopse: sinopse,
      ano: ano
    });

    mensagem.textContent = 'Filme cadastrado com sucesso!';
    mensagem.className = 'mt-4 text-sm text-green-600';

    form.reset();

    mostraFilmes();

  });

  // Mostra os filmes na tabela
  function mostraFilmes() {

    listaFilmes.innerHTML = '';

    // Cria uma cópia e ordena do mais recente para o mais antigo
    const filmesOrdenados = [...filmes].sort((a, b) => b.ano - a.ano);

    filmesOrdenados.forEach((filme) => {

      const linha = document.createElement('tr');

      linha.className = 'hover:bg-gray-100';

      linha.innerHTML = `
        <td class="border border-gray-300 px-4 py-2 font-semibold">
          ${filme.titulo}
        </td>

        <td class="border border-gray-300 px-4 py-2">
          ${filme.sinopse}
        </td>

        <td class="border border-gray-300 px-4 py-2 text-center">
          ${filme.ano}
        </td>
      `;

      listaFilmes.appendChild(linha);
    });
  }

});